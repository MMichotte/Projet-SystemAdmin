<p>Bienvenue sur l'<b><span style="color:red">intranet !</span></b></p>
<?php 
echo '----------PHP----------'."<br><br>";
echo 'Version courante de PHP : '.'<b><span style="color:blue">' . Phpversion().'</b></span><br><br>';
echo '----------PHP----------';
 ?>
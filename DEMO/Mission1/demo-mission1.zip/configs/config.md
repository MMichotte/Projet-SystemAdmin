<h1>Configuration du réseau (Mission 1 - Démo) :</h1> 

<fieldset style="width:150px">
    <legend style="text-align:center"><span style="color:red">Groupe n°5</span></legend>
    <li><b><span style="color:purple">Morgan Valentin</b></span></li>
    <li><b><span style="color:purple">Martin Michotte</b></li>
    <li><b><span style="color:purple">Olivier Niyonkuru</b></li>
</fieldset>
<h2><b><u> Schéma proposé :</u></b></h2> 

<img src="img/demo1.png">

<span style="color:red"> Reseau => 172.16.0.0 (/29)</span>\
<span style="color:blue">domaine => wt2-5.ephec-ti.be</span>

<p style="page-break-before:always">

<h2><b> 1. <u>Configuration du Résolveur</u></b></h2>

<h3><b><u> Configuration de base :</u></b></h3>

- <span style="color:red">ip => 172.16.0.3  masque => 255.255.255.248 (/29)</span>
- <span style="color:green">gateway => 172.16.0.1</span>
- <span style="color:blue">nameserver=172.16.0.3 (lui-même) </span>
- **⚠ Attention ! Mettre le nameserver dans le client !**
  - `(fichier /etc/resolv.conf)`

<h3><b><u> Configuration avancée :</u></b></h3> 

```shell
bind# cd /etc/bind
bind# cp named.conf.recursive named.conf #Copier le fichier
bind# vi named.conf                      #Modifier le fichier
```
Dans **`named.conf`**, **dans** la section **`"options"`** **modifier** les lignes suivantes :

```shell
allow-recursion {
	172.16.0.0/29;
};

listen-on port 53 { any; };
listen-on-v6 { none; };
```
Dans **`named.conf`**, **APRES** la section **`"options"`** **ajouter** les lignes suivantes : 

```shell
# Notre zone
zone "wt2-5.ephec-ti.be" {
    type forward;
    forwarders {172.16.0.2;};
    forward only;
};

# Zone reverse
zone "0.16.172.in-addr.arpa" {
    type forward;
    forwarders {172.16.0.2;};
    forward only;
};
```
<u><b>Puis après tous cela, on lance bind :</b></u> 

```shell
bind# named -g
```

<h3><b><u><span style="color:blue"> Test du fonctionnement de notre résolveur :</span></u></b></h3>

Le client => dig A **`www.google.com`**\
Le résolveur => Cherche l'adresse IP de **`www.google.com`** (RR de type A)
> Si le résolveur essaye de répondre (même si il n'y arrive pas) à la requête du client, celui-ci fonctionne bien.

<p style="page-break-before:always">

<h2><b> 2. <u>Configuration du SOA (Interne)</u></b></h2>

<h3><b><u> Configuration de base :</u></b></h3>

- <span style="color:red">ip => 172.16.0.2  masque => 255.255.255.248 (/29)</span>
- <span style="color:green">gateway => 172.16.0.1</span>

<h3><b><u> Configuration avancée :</u></b></h3> 

```shell
bind# cd /etc/bind
bind# cp named.conf.authoritative named.conf #Copier le fichier
bind# vi named.conf                          #Modifier le fichier
```
Dans **`named.conf`**, **dans** la section **`"options"`** **modifier** les lignes suivantes :


```shell
listen-on { 172.16.0.2; };
listen-on-v6 { none; };

allow-query {
	127.0.0.1;
	172.16.0.0/29;
};

allow-recursion { none; };
recursion no;
```
Dans **`named.conf`**, **APRES** la section **`"options"`** **ajouter** les lignes suivantes : 

```shell
# Notre zone
zone "wt2-5.ephec-ti.be" {
    type master;
    file "/etc/bind/wt2-5.ephec-ti.be"
};

# Zone reverse
zone "0.16.172.in-addr.arpa" IN {
    type master;
    file "/etc/bind/0.16.172.in-addr.arpa";
};
```
<p style="page-break-before:always">

<h3><b><u> Configuration des fichiers de zone :</u></b></h3>

Toujours dans le dossier bind (/etc/bind/), ajouter/ créer 2 fichiers : 
- Le fichier de **zone** => **`wt2-5.ephec-ti.be`**
- Le fichier de **zone reverse** => **`0.16.172.in-addr.arpa`**

**Zone "`wt2-5.ephec-ti.be`" :**

<img src="img/zone.png">

**Zone "`0.16.172.in-addr.arpa`" :**

<img src="img/zoneReverse.png">

<p style="page-break-before:always">

<h3><b><u><span style="color:blue"> Test du fonctionnement de notre SOA :</span></u></b></h3>

1. **Demande d'information sur le domaine**

```shell
Client# dig wt2-5.ephec-ti.be.
```
<img src="img/test1.png">

2. **Demande d'information sur l'ip "`172.16.0.4`" (_reverse query / iquery_)**

```shell
Client# host 172.16.0.4
```
<img src="img/test2.png">

<p style="page-break-before:always">

<h2><b> 3. <u>Configuration du serveur Apache</u></b></h2>

<h3><b> a) On commence par créer notre site (intranet) :</b></h3>

```shell
apache# mkdir /var/www/intranet
apache# touch /var/www/intranet/index.html
apache# vi /var/www/intranet/index.html
```
<h3><b> b) On ajoute ensuite le code html de notre page :</b></h3> 

```html
<html>
<h1>Bienvenue dans l'intranet !</h1>
</html>
```

<h3><b> c) Création du fichier de config :</b></h3>

```shell
apache# cd /etc/apache2/sites-available
apache# touch intranet.conf
```
<p style="page-break-before:always">

<h3><b> d) Configuration du fichier de config  :</b></h3>

Dans le fichier **"`intranet.conf`"** (créer au point précédent), ajouter ceci :

<img src="img/config1.png">

<h3><b> e) Activer notre configuration :</b></h3> 

```shell
apache# cd /etc/apache2/sites-available
apache# a2ensite intranet.conf
apache# service apache2 reload
```

<h3><b><u><span style="color:blue"> Test du fonctionnement de notre serveur apache :</span></b></u></h3>

<img src="img/intranet.png">

<p style="page-break-before:always">

**On fait la même chose pour les 2 autres sites (b2b et www), ce qui donne après test ceci :**

<img src="img/b2b.png">

<br><br>

<img src="img/www.png">

<h3><b><u><span style="color:green"> Securité :</span></b></u></h3> 

Lorsque l'on "tombe" sur une page qui n'existe pas, on a un message d'erreur avec des informations sur notre version d'apache, notre système d'exploitation, et d'autres encore...\
En connaissant notre verson d'apache et notre OS, un hacker peut facilement trouver un "exploit" pour "attacker" notre serveur.\
#### Screenshot de la situation :

<img src="img/security1.png">

<p style="page-break-before:always">

#### Solution ?

**Modifier le fichier "`apache2.conf`" (/etc/apache2/apache2.conf) et ajouter ces lignes-ci (tout en bas du fichier) :** 

```shell
# Security
ServerSignature Off
ServerTokens Prod
```
**On doit ensuite redémarer apache :**

```shell
apache# service apache2 restart
```
**Voilà le problème régler !**

<img src="img/security2.png">

<h3><b><u> BONUS :</b></u></h3>

Si une machine tente de contacter notre serveur web sur son ip, il va refuser (erreur 403) afin de laisser uniquement les "bons" nom de domaine / les noms de domaines authorisé. 

<img src="img/forbidden.png">